import java.util.ArrayList;
import java.util.LinkedList;

public class Main {
	public static void main(String[] args) {
		
		LinkedList<String> namesLinkedList = new LinkedList<>();//Elemanları ekleyip çıkarmada daha iyi
		namesLinkedList.add("utku");//0                          
		namesLinkedList.add("deniz");//1
		namesLinkedList.add("mehmet");//2
		namesLinkedList.add("hazal");//3
		System.out.println(namesLinkedList.get(2));
		namesLinkedList.add(1, "kenan");//Boşluk yaaratır ve yerine yenisini ekler
		System.out.println(namesLinkedList.get(1));
		System.out.println(namesLinkedList);
		System.out.println();
		
		
		String[] names = new String[4];
		ArrayList<String> nameArrayList = new ArrayList<>();//Elemenaları getirmede daha iyi
		nameArrayList.add("utku");//0
		nameArrayList.add("deniz");//1
		nameArrayList.add("mehmet");//2
		nameArrayList.add("hazal");//3
		System.out.println(nameArrayList.get(2));
		nameArrayList.add(1, "kenan");//Eklenencek indexin yerine gelecek olan Stringi kaydırır ve yerine yenisini yazar
		System.out.println(nameArrayList.get(1));
		System.out.println(nameArrayList);
		
		//Her ikisinde de remove komutu ile elemanlar çıkartılır. 
	    //LinkdList daha avantajlı gözükse de ArrayListin de daha avantajlı olduğu projeler yaplıabilir.
	}
}
